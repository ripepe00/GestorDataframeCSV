#include <windows.h>
#include <string.h>
#include <stdio.h>
#include <ctype.h>
#include <time.h>
#include "lib.h"

#define BLACK         0
#define BLUE          1
#define GREEN         2
#define CYAN          3
#define RED           4
#define MAGENTA       5
#define BROWN         6
#define LIGHTGRAY     7
#define DARKGRAY      8
#define LIGHTBLUE     9
#define LIGHTGREEN   10
#define LIGHTCYAN    11
#define LIGHTRED     12
#define LIGHTMAGENTA 13
#define YELLOW       14
#define WHITE        15

void TextColor(int color)
{
    static int __BACKGROUND;

    HANDLE h = GetStdHandle ( STD_OUTPUT_HANDLE );
    CONSOLE_SCREEN_BUFFER_INFO csbiInfo;

    GetConsoleScreenBufferInfo(h, &csbiInfo);
    SetConsoleTextAttribute (GetStdHandle (STD_OUTPUT_HANDLE), color + (__BACKGROUND << 4));
}

char* trim(char *frase) {
    int i = 0, j = 0;

    if(frase == NULL)
        return NULL;

    // Recorre la cadena y copia solo los caracteres que no sean espacios
    while (frase[i] != '\0') {
        if (frase[i] != ' ' && frase[i] != '\n' && frase[i] != '\t') {
            frase[j++] = frase[i];
        }
        i++;
    }

    // Añade el terminador nulo al final de la cadena modificada
    frase[j] = '\0';
    return frase;
}

// Función análoga a strtok, pero cuando hay dos delimitadores consecutivos, devuelve NULL
char *tokenizador(char *linea, char delimitador)
{
    static char *buffer;
    if (linea != NULL)
        buffer = linea;
    if (buffer == NULL)
        return NULL;
    char *inicio = buffer;
    while (*buffer != delimitador && *buffer != '\0')
        buffer++;
    if (*buffer == '\0')
    {
        buffer = NULL;
        return inicio;
    }
    *buffer = '\0';
    buffer++;
    return inicio;
}

int ValidarFecha(const char *fecha) {
    int anio, mes, dia;

    // Validar longitud
    if (strlen(fecha) != 10) {
        return 0; // Formato incorrecto
    }

    // Validar separadores
    if ((fecha[4] != '/' && fecha[4] != '-') || fecha[4] != fecha[7]) {
        return 0; // Separadores incorrectos
    }

    // Extraer año, mes y día
    anio = (fecha[0] - '0') * 1000 + (fecha[1] - '0') * 100 + (fecha[2] - '0') * 10 + (fecha[3] - '0');
    mes = (fecha[5] - '0') * 10 + (fecha[6] - '0');
    dia = (fecha[8] - '0') * 10 + (fecha[9] - '0');

    // Validar rangos básicos
    if (anio < 1 || mes < 1 || mes > 12 || dia < 1 || dia > 31) {
        return 0;
    }

    // Validar días según el mes
    if (mes == 4 || mes == 6 || mes == 9 || mes == 11) {
        if (dia > 30) {
            return 0; // Meses con 30 días
        }
    } else if (mes == 2) {
        // Validar febrero con lógica de bisiestos integrada
        if ((anio % 400 == 0 || (anio % 4 == 0 && anio % 100 != 0))) {
            if (dia > 29) {
                return 0; // Febrero en año bisiesto
            }
        } else {
            if (dia > 28) {
                return 0; // Febrero en año no bisiesto
            }
        }
    }

    // Pasa todas las validaciones
    return 1;
}

int ValidarNumeroDecimal(const char *cadenad) {
    int longitud = strlen(cadenad);
    int puntoDecimal = 0;
    int i;

    // Verificar si la cadena está vacía
    if (longitud == 0) return 0;

    // Verificar el primer carácter (puede ser un signo o un dígito)
    if (cadenad[0] != '+' && cadenad[0] != '-' && !isdigit(cadenad[0])) return 0;

    // Recorrer el resto de la cadena
    for (i = 1; i < longitud; i++) {
        if (cadenad[i] == '.') {
            // Verificar que no haya más de un punto decimal
            if (puntoDecimal) return 0;
            puntoDecimal = 1;
        } else if (!isdigit(cadenad[i])) {
            // Si no es un dígito ni un punto, no es válido
            return 0;
        }
    }

    // Verificar que no termine en punto
    if (cadenad[longitud - 1] == '.') return 0;

    return 1;

}

int ValidarNumeroEntero(const char *cadenae) {
    int longitud = strlen(cadenae);
    int i = 0;

    // Verificar si la cadena está vacía
    if (longitud == 0) return 0;

    // Manejar el signo si está presente
    if (cadenae[0] == '+' || cadenae[0] == '-') {
        i = 1;
        // Si solo hay un signo, no es válido
        if (longitud == 1) return 0;
    }

    // Verificar que todos los caracteres restantes sean dígitos
    for (; i < longitud; i++) {
        if (!isdigit(cadenae[i])) {
            return 0;
        }
    }

    // Si llegamos aquí, es un número entero válido
    return 1;
}

int ObtenerNumeroColumnas(const char *linea, char delimitador)
{
    int numColumnas = 0;
    // solo hay que contar el número de delimitadores + 1
    for (int i = 0; linea[i] != '\0'; i++)
    {
        if (linea[i] == delimitador)
            numColumnas++;
    }
    return numColumnas + 1;
}


TipoDato ObtenerTipo(const char *dato)
{
    if (ValidarNumeroDecimal(dato))
        return NUMERICO;
    else if (ValidarFecha(dato))
        return FECHA;
    else
        return TEXTO;
}

// RECORDAR: malloc y calloc pueden devolver NULL si no hay memoria disponible
// En ese caso, se debe liberar la memoria previamente asignada y devolver NULL
Dataframe* crearDataframe(int numColumnas, int numFilas, TipoDato *tipos, char *encabezados[]) {
    Dataframe *df = (Dataframe *)malloc(sizeof(Dataframe));
    if (df == NULL) {
        TextColor(RED);
        printf("Error: No se pudo asignar memoria para el Dataframe\n");
        TextColor(WHITE);
        return NULL;
    }

    df->numColumnas = numColumnas;
    df->numFilas = numFilas;
    df->columnas = (Columna *)malloc(numColumnas * sizeof(Columna));
    if (df->columnas == NULL) {
        free(df);
        TextColor(RED);
        printf("Error: No se pudo asignar memoria para las columnas del Dataframe\n");
        TextColor(WHITE);
        return NULL;
    }

    df->indice = (int *)malloc(numFilas * sizeof(int));
    if (df->indice == NULL) {
        free(df->columnas);
        free(df);
        TextColor(RED);
        printf("Error: No se pudo asignar memoria para los índices del Dataframe\n");
        TextColor(WHITE);
        return NULL;
    }

    for (int i = 0; i < numFilas; i++) {
        df->indice[i] = i;
    }

    for (int i = 0; i < numColumnas; i++) {
        strcpy(df->columnas[i].nombre, encabezados[i]);
        df->columnas[i].tipo = tipos[i];
        df->columnas[i].numFilas = numFilas;
        df->columnas[i].esNulo = (unsigned char *)calloc(numFilas, sizeof(unsigned char));
        if (df->columnas[i].esNulo == NULL) {
            for (int j = 0; j <= i; j++) {
                free(df->columnas[j].esNulo);
                free(df->columnas[j].datos);
            }
            free(df->indice);
            free(df->columnas);
            free(df);
            TextColor(RED);
            printf("Error: No se pudo asignar memoria para esNulo de la columna %s\n", encabezados[i]);
            TextColor(WHITE);
            return NULL;
        }

        switch (tipos[i]) {
            case TEXTO:
                df->columnas[i].datos = malloc(numFilas * sizeof(char *));
                break;
            case NUMERICO:
                df->columnas[i].datos = malloc(numFilas * sizeof(double));
                break;
            case FECHA:
                df->columnas[i].datos = malloc(numFilas * sizeof(struct tm));
                break;
        }

        if (df->columnas[i].datos == NULL) {
            for (int j = 0; j <= i; j++) {
                free(df->columnas[j].esNulo);
                free(df->columnas[j].datos);
            }
            free(df->indice);
            free(df->columnas);
            free(df);
            TextColor(RED);
            printf("Error: No se pudo asignar memoria para datos de la columna %s\n", encabezados[i]);
            TextColor(WHITE);
            return NULL;
        }
    }

    TextColor(GREEN);
    printf("Dataframe creado exitosamente\n");
    TextColor(WHITE);
    return df;
}

// Liberar la memoria de un DataFrame
void EliminarDataframe(Dataframe *df){
    if (df == NULL) return;

    for (int i = 0; i < df->numColumnas; i++) {
        free(df->columnas[i].datos);
        free(df->columnas[i].esNulo);
    }
    free(df->columnas);
    free(df->indice);
    free(df);
}

// Inserta un DataFrame al final de la lista
int InsertarDataframeAlFinal(Lista *lista, Dataframe *df)
{
    Nodo *nuevoNodo = (Nodo *)malloc(sizeof(Nodo));
    if (nuevoNodo == NULL)
        return 0;
    nuevoNodo->df = df;
    nuevoNodo->siguiente = NULL;
    if (lista->primero == NULL)
    {
        lista->primero = nuevoNodo;
    }
    else
    {
        Nodo *actual = lista->primero;
        while (actual->siguiente != NULL)
            actual = actual->siguiente;
        actual->siguiente = nuevoNodo;
    }
    lista->numDFs++;
    return 1;
}


// Carga un fichero CSV en un DataFrame
// si el fichero es incorrecto, devuelve NULL
Dataframe *load(const char *nombre_archivo, char delimitador, int incrementarContador) {
    if (delimitador == '\0') {
        delimitador = ','; // Usar coma como delimitador predeterminado
    }

    FILE *fichero = fopen(nombre_archivo, "r");
    if (fichero == NULL) {
        TextColor(RED);
        perror("Error al abrir el archivo");
        TextColor(WHITE);
        return NULL;
    }

    char lineaEncabezado[5001];
    char *encabezados[500];
    char lineaDatos[5001];
    TipoDato tipos[500];
    char *token;
    int numFilas, numColumnas, numTokens;
    Dataframe *df = NULL;

    // Leer la primera línea: encabezados
    if (fgets(lineaEncabezado, 5000, fichero) == NULL || trim(lineaEncabezado) == NULL || strlen(lineaEncabezado) == 0) {
        TextColor(RED);
        printf("Error al leer el archivo\n");
        TextColor(WHITE);
        fclose(fichero);
        return NULL;
    }

    // Tokenizar el encabezado (primera línea)
    numTokens = 0;
    token = tokenizador(lineaEncabezado, delimitador);
    while (token != NULL) {
        encabezados[numTokens] = trim(token);
        numTokens++;
        token = tokenizador(NULL, delimitador);
    }
    numColumnas = numTokens;

    // Leer la segunda línea: tipos de datos, guardar en el array tipos
    if (fgets(lineaDatos, 5000, fichero) == NULL || trim(lineaDatos) == NULL || strlen(lineaDatos) == 0) {
        TextColor(RED);
        printf("Error al leer el archivo\n");
        TextColor(WHITE);
        fclose(fichero);
        return NULL;
    }
    numTokens = 0;
    token = tokenizador(lineaDatos, delimitador);
    while (token != NULL) {
        trim(token);
        if (strlen(token) == 0) {
            TextColor(RED);
            printf("Error: valor nulo en la fila de tipos de datos\n");
            TextColor(WHITE);
            fclose(fichero);
            return NULL;
        }
        tipos[numTokens] = ObtenerTipo(token);
        numTokens++;
        token = tokenizador(NULL, delimitador);
    }
    if (numTokens != numColumnas) {
        TextColor(RED);
        printf("Error en la cantidad de tipos especificada\n");
        TextColor(WHITE);
        fclose(fichero);
        return NULL;
    }

    // Verificar si hay algún valor nulo en la primera fila de datos
    for (int i = 0; i < numColumnas; i++) {
        if (tipos[i] == TEXTO && strlen(encabezados[i]) == 0) {
            TextColor(RED);
            printf("Error: valor nulo en la primera fila de datos\n");
            TextColor(WHITE);
            fclose(fichero);
            return NULL;
        }
    }

    // Leer el resto del fichero para contar las filas correctas
    numFilas = 1; // ya hemos leído la segunda línea, que es la primera fila de datos del CSV
    while (fgets(lineaDatos, 5000, fichero) != NULL) {
        numTokens = 0;
        token = tokenizador(lineaDatos, delimitador);
        while (token != NULL) {
            numTokens++;
            token = tokenizador(NULL, delimitador);
        }
        if (numTokens == numColumnas)
            numFilas++;
    }

    // Crear el DataFrame
    df = crearDataframe(numColumnas, numFilas, tipos, encabezados);
    if (df == NULL) {
        TextColor(RED);
        printf("Error al crear el dataframe\n");
        TextColor(WHITE);
        fclose(fichero);
        return NULL;
    }

    // Asignar nombre automáticamente
    static int dfCounter = 0;
    if (incrementarContador) {
        sprintf(df->name, "df%d", dfCounter++);
    } else {
        sprintf(df->name, "temp_df");
    }

    // Inicializar el índice
    df->indice = (int *)malloc(numFilas * sizeof(int));
    if (df->indice == NULL) {
        TextColor(RED);
        printf("Error al asignar memoria para el índice\n");
        TextColor(WHITE);
        EliminarDataframe(df);
        fclose(fichero);
        return NULL;
    }

    // Volver al principio del fichero y leer los datos para rellenar el DataFrame
    rewind(fichero);
    fgets(lineaEncabezado, 5000, fichero); // saltar la primera línea
    numFilas = 0;
    while (fgets(lineaDatos, 5000, fichero) != NULL) {
        if (ObtenerNumeroColumnas(lineaDatos, delimitador) != numColumnas)
            continue;

        numTokens = 0;
        token = tokenizador(lineaDatos, delimitador);
        while (token != NULL) {
            if (!insertarDato(df, numFilas, numTokens, trim(token))) {
                TextColor(RED);
                printf("Error al insertar dato\n");
                TextColor(WHITE);
                EliminarDataframe(df);
                fclose(fichero);
                return NULL;
            }
            numTokens++;
            token = tokenizador(NULL, delimitador);
        }
        df->indice[numFilas] = numFilas; // Asignar el índice
        numFilas++;
    }

    fclose(fichero);
    return df;
}

void inicializarLista(Lista *lista) {
    lista->numDFs = 0;
    lista->primero = NULL;
}

void liberarDataframe(Dataframe *df) {
    for (int i = 0; i < df->numColumnas; i++) {
        if (df->columnas[i].tipo == TEXTO) {
            for (int j = 0; j < df->numFilas; j++) {
                free(((char **)df->columnas[i].datos)[j]);
            }
        }
        free(df->columnas[i].datos);
        free(df->columnas[i].esNulo);
    }
    free(df->columnas);
    free(df->indice);
}

void liberarLista(Lista *lista) {
    Nodo *actual = lista->primero;
    while (actual != NULL) {
        Nodo *siguiente = actual->siguiente;
        liberarDataframe(actual->df);
        free(actual->df);
        free(actual);
        actual = siguiente;
    }
    lista->numDFs = 0;
    lista->primero = NULL;
}


void agregarColumna(Dataframe *df, const char *nombre, TipoDato tipo, int indice) {
    strcpy(df->columnas[indice].nombre, nombre);
    df->columnas[indice].tipo = tipo;
    df->columnas[indice].numFilas = df->numFilas;
    df->columnas[indice].esNulo = (unsigned char *)malloc(df->numFilas * sizeof(unsigned char));
    if (df->columnas[indice].esNulo == NULL) {
        TextColor(RED);
        printf("Error al asignar memoria para esNulo\n");
        TextColor(WHITE);
        return;
    }
    memset(df->columnas[indice].esNulo, 0, df->numFilas * sizeof(unsigned char));

    switch (tipo) {
        case TEXTO:
            df->columnas[indice].datos = malloc(df->numFilas * sizeof(char *));
            if (df->columnas[indice].datos == NULL) {
                TextColor(RED);
                printf("Error al asignar memoria para datos de tipo TEXTO\n");
                TextColor(WHITE);
                free(df->columnas[indice].esNulo);
                return;
            }
            break;
        case NUMERICO:
            df->columnas[indice].datos = malloc(df->numFilas * sizeof(double));
            if (df->columnas[indice].datos == NULL) {
                TextColor(RED);
                printf("Error al asignar memoria para datos de tipo NUMERICO\n");
                TextColor(WHITE);
                free(df->columnas[indice].esNulo);
                return;
            }
            break;
        case FECHA:
            df->columnas[indice].datos = malloc(df->numFilas * sizeof(struct tm));
            if (df->columnas[indice].datos == NULL) {
                TextColor(RED);
                printf("Error al asignar memoria para datos de tipo FECHA\n");
                TextColor(WHITE);
                free(df->columnas[indice].esNulo);
                return;
            }
            break;
    }
}



// Guarda un dato en la fila,columna que le corresponde
// siempre que el tipo coincida con el tipo de la columna
// si no coincide o si el dato es NULL o cadena vacía, se marca como nulo
// en caso de fallo de memoria se devuelve 0, en caso contrario 1
int insertarDato(Dataframe *df, int fila, int columna, const char *dato)
{
    Fecha fecha;

    if (dato == NULL || dato[0] == '\0' || df->columnas[columna].tipo != ObtenerTipo(dato))
    {
        df->columnas[columna].esNulo[fila] = 1;
        return 1;
    }

    switch (df->columnas[columna].tipo)
    {
        case TEXTO:
            ((char **)df->columnas[columna].datos)[fila] = strdup(dato);
            if(((char **)df->columnas[columna].datos)[fila] == NULL)
                return 0;
            break;
        case NUMERICO:
            ((double *)df->columnas[columna].datos)[fila] = atof(dato);
            break;
        case FECHA:
            fecha.tm_year = atoi(dato) - 1900;
            fecha.tm_mon = atoi(dato + 5) - 1;
            fecha.tm_mday = atoi(dato + 8);
            fecha.tm_hour = fecha.tm_min = fecha.tm_sec = 0;
            ((Fecha *)df->columnas[columna].datos)[fila] = fecha;
            break;
    }

    return 1;
}


void listarDataframes(Lista *lista) {
    Nodo *actual = lista->primero;
    if (actual == NULL) {
        printf("No hay dataframes en memoria\n");
        return;
    }

    printf("Dataframes en memoria:\n");
    while (actual != NULL) {
        printf("%s: %d filas , %d columnas\n",  actual->df->name , actual->df->numFilas, actual->df->numColumnas);
        actual = actual->siguiente;
    }
}
/*
void cargarDataframeDesdeCSV(Lista *lista, const char *nombreArchivo) {
    FILE *file = fopen(nombreArchivo, "r");
    if (file == NULL) {
        perror("Error al abrir el archivo");
        return;
    }

    char linea[1024];
    char *token;
    int numColumnas = 0;
    Dataframe *df = NULL;
    Nodo *nd = NULL;

    // Leer encabezados
    if (fgets(linea, sizeof(linea), file) != NULL) {
        token = strtok(linea, ",\n ");
        while (token != NULL) {
            printf("Encabezado: %s\n", token);
            token = strtok(NULL, ",\n ");
            numColumnas++;
        }
    }
    char **nombresColumnas = (char **)malloc(numColumnas * sizeof(char *));
    for (int i = 0; i < numColumnas; i++) {
        nombresColumnas[i] = (char *)malloc(256 * sizeof(char)); // Asumiendo un tamaño máximo de 100 caracteres por nombre
    }
    rewind(file);
    fgets(linea, sizeof(linea), file); // Leer encabezados nuevamente
    if(fgets(linea, sizeof(linea), file) != NULL){
        token = strtok(linea, ",\n ");
        int tipos = 0;
        while (token != NULL) {
            if(ValidarNumeroDecimal(token)){
                nombresColumnas[tipos] = "NUMERICO";
            } else if(ValidarFecha(token)){
                nombresColumnas[tipos] = "FECHA";
            } else {
                nombresColumnas[tipos] = "TEXTO";
            }
            token = strtok(NULL, ",\n ");
            tipos++;
        }
        if(tipos != numColumnas){
            printf("Error en la cantidad de tipos especificada\n");
            return;
        }
    }
    printf("Numero de columnas: %d\n", numColumnas);
    df = crearDataframe(numColumnas, 0);
    strcpy(df->name,nombreArchivo);
    nd = (Nodo *)malloc(sizeof(Nodo));
    nd->df = df;
    nd->siguiente = lista->primero;
    lista->primero = nd;
    lista->numDFs++;
    int i;
    int fila = 0;
    for(i=0;i<df->numColumnas;i++){
        agregarColumna(df,nombresColumnas[i],stringToType(nombresColumnas[i]),i);
    }
    while (fgets(linea, sizeof(linea), file) != NULL) {
        printf("Linea %d: %s",fila, linea);
        token = strtok(linea, ",\n ");
        for (int i = 0; i < numColumnas; i++) {
            insertarDato(df, fila, i, token);
            token = strtok(NULL, ",\n ");
        }
        fila++;
    }
    df->numFilas = fila;
    fclose(file);
    printf("Dataframe cargado correctamente desde %s\n", nombreArchivo);
}
*/

int validarDato(const char *dato, TipoDato tipo) {
    switch (tipo) {
        case TEXTO:
            return 1;
        case NUMERICO:
            return ValidarNumeroDecimal(dato);
        case FECHA:
            return ValidarFecha(dato);
        default:
            return 0;
    }
}
/*
void abrirCSV(Lista *lista , const char *nombreArchivo){

    FILE *file = fopen(nombreArchivo, "r");
    if (file == NULL) {
        TextColor(RED);
        printf("Error al abrir el archivo\n");
        TextColor(WHITE);
        return;
    }

    char linea[1024];
    char *token;
    int numColumnas = 0;
    int numFilas = 0;
    Dataframe *df = NULL;
    Nodo *nd = NULL;

    // Leer encabezados
    if (fgets(linea, sizeof(linea), file) != NULL) {
        token = strtok(linea, ",\n ");
        while (token != NULL) {
            numColumnas++;
            token = strtok(NULL, ",\n ");
        }
    }

    char **nombresColumnas = (char **)malloc(numColumnas * sizeof(char *));
    for (int i = 0; i < numColumnas; i++) {
        nombresColumnas[i] = (char *)malloc(256 * sizeof(char));
    }
    
    rewind(file);
    
    // Primera fila: Leer encabezados
    if (fgets(linea, sizeof(linea), file) != NULL) {
        token = strtok(linea, ",\n ");
        int i = 0;
        while (token != NULL && i < numColumnas) {
            printf("Encabezado: %s\n", token);
            strcpy(nombresColumnas[i], token);
            token = strtok(NULL, ",\n ");
            i++;
        }
    }

    TipoDato tiposArray[1024];

    // Segunda fila: Leer tipos de datos
    if (fgets(linea, sizeof(linea), file) != NULL) {
        token = strtok(linea, ",\n ");
        int tipos = 0;
        while (token != NULL) {
            if (ValidarNumeroDecimal(token)) {
                tiposArray[tipos] = NUMERICO;
            } else if (ValidarFecha(token)) {
                tiposArray[tipos] = FECHA;
            } else {
                tiposArray[tipos] = TEXTO;
            }
            token = strtok(NULL, ",\n ");
            tipos++;
        }
        if (tipos != numColumnas) {
            TextColor(RED);
            printf("Error en la cantidad de tipos especificada\n");
            TextColor(WHITE);
            return;
        }
    }

    // Recorrer el archivo CSV y calcular el número de filas correctas
    // una fila es correcta si tiene el mismo número de columas que la primera fila
    // y coinciden los tipos de datos
    numFilas = 1; // Contar la primera fila que ya se ha leido anteriormente
    while (fgets(linea, sizeof(linea), file) != NULL) {
        token = strtok(linea, ",\n ");
        int i = 0;
        while (token != NULL && i < numColumnas) {
            if (i >= numColumnas) {
                TextColor(RED);
                printf("Error en la fila %d: demasiados campos\n", numFilas);
                TextColor(WHITE);
                return;
            }
            if (!validarDato(token, tiposArray[i])) {
                TextColor(RED);
                printf("Error en la fila %d, columna %d: tipo de dato incorrecto\n", numFilas, i);
                TextColor(WHITE);
                return;
            }
            token = strtok(NULL, ",\n ");
            i++;
        }
        if (i < numColumnas) {
            TextColor(RED);
            printf("Error en la fila %d: faltan campos\n", numFilas);
            TextColor(WHITE);
            return;
        }
        numFilas++;
    }

    df = crearDataframe(numColumnas, numFilas);
    strcpy(df->name, nombreArchivo);
    nd = (Nodo *)malloc(sizeof(Nodo));
    nd->df = df;
    nd->siguiente = lista->primero;
    lista->primero = nd;
    lista->numDFs++;
    
    for (int i = 0; i < df->numColumnas; i++) {
        agregarColumna(df, nombresColumnas[i], tiposArray[i], i);
    }

    while (fgets(linea, sizeof(linea), file) != NULL) {
        token = strtok(linea, ",\n ");
        for (int i = 0; i < numColumnas; i++) {
            printf(" %d: %s\n", df->columnas[i].tipo, token);
            if (token == NULL || (strlen(token) == 1 && (token[0] == ' ' || token[0] == '\n')) || !validarDato(token, df->columnas[i].tipo)) {
                df->columnas[i].esNulo[numFilas] = 1;
            } else {
                insertarDato(df, numFilas, i, token);
            }
            token = strtok(NULL, ",\n ");
        }
        numFilas++;
    }
    df->numFilas = numFilas;
    fclose(file);

    TextColor(GREEN);
    printf("Dataframe cargado correctamente desde %s\n", nombreArchivo);
    printf("Dataframe activo: %s\n", df->name);
    TextColor(WHITE);
}
*/

//Ordenar las filas por el métdo de la burbuja
//se debe pasar el nombre de la columna por la cual se va a ordenar y el nombre
//la ordenación se hará según el tipo de la columna
//en el caso de que sea NUMERICO será simplemente una comparación de los valores
//en el caso de que sea TEXTO se tendrá en cuenta el orden alfabetico
//en el caso de que sea FECHA se tendrá en cuenta la fecha

void ordenar(Dataframe *df, const char *nombreColumna, const char *orden) {
    int columna_index = -1;
    for (int i = 0; i < df->numColumnas; i++) {
        if (strcmp(df->columnas[i].nombre, nombreColumna) == 0) {
            columna_index = i;
            break;
        }
    }

    if (columna_index == -1) {
        TextColor(RED);
        printf("La columna %s no existe\n", nombreColumna);
        TextColor(WHITE);
        return;
    }

    int ascendente = strcmp(orden, "asc") == 0;

    for (int i = 0; i < df->numFilas - 1; i++) {
        for (int j = 0; j < df->numFilas - i - 1; j++) {
            int intercambiar = 0;

            if (df->columnas[columna_index].esNulo[j] && !df->columnas[columna_index].esNulo[j + 1]) {
                intercambiar = ascendente ? 0 : 1;
            } else if (!df->columnas[columna_index].esNulo[j] && df->columnas[columna_index].esNulo[j + 1]) {
                intercambiar = ascendente ? 1 : 0;
            } else if (!df->columnas[columna_index].esNulo[j] && !df->columnas[columna_index].esNulo[j + 1]) {
                switch (df->columnas[columna_index].tipo) {
                    case TEXTO:
                        if (ascendente) {
                            if (strcmp(((char **)df->columnas[columna_index].datos)[j], ((char **)df->columnas[columna_index].datos)[j + 1]) > 0) {
                                intercambiar = 1;
                            }
                        } else {
                            if (strcmp(((char **)df->columnas[columna_index].datos)[j], ((char **)df->columnas[columna_index].datos)[j + 1]) < 0) {
                                intercambiar = 1;
                            }
                        }
                        break;
                    case NUMERICO:
                        if (ascendente) {
                            if (((double *)df->columnas[columna_index].datos)[j] > ((double *)df->columnas[columna_index].datos)[j + 1]) {
                                intercambiar = 1;
                            }
                        } else {
                            if (((double *)df->columnas[columna_index].datos)[j] < ((double *)df->columnas[columna_index].datos)[j + 1]) {
                                intercambiar = 1;
                            }
                        }
                        break;
                    case FECHA:
                        if (ascendente) {
                            if (mktime(&((Fecha *)df->columnas[columna_index].datos)[j]) > mktime(&((Fecha *)df->columnas[columna_index].datos)[j + 1])) {
                                intercambiar = 1;
                            }
                        } else {
                            if (mktime(&((Fecha *)df->columnas[columna_index].datos)[j]) < mktime(&((Fecha *)df->columnas[columna_index].datos)[j + 1])) {
                                intercambiar = 1;
                            }
                        }
                        break;
                }
            }

            if (intercambiar) {
                for (int k = 0; k < df->numColumnas; k++) {
                    if (df->columnas[k].tipo == TEXTO) {
                        char *tempDato = ((char **)df->columnas[k].datos)[j];
                        ((char **)df->columnas[k].datos)[j] = ((char **)df->columnas[k].datos)[j + 1];
                        ((char **)df->columnas[k].datos)[j + 1] = tempDato;
                    } else if (df->columnas[k].tipo == NUMERICO) {
                        double tempDato = ((double *)df->columnas[k].datos)[j];
                        ((double *)df->columnas[k].datos)[j] = ((double *)df->columnas[k].datos)[j + 1];
                        ((double *)df->columnas[k].datos)[j + 1] = tempDato;
                    } else if (df->columnas[k].tipo == FECHA) {
                        Fecha tempDato = ((Fecha *)df->columnas[k].datos)[j];
                        ((Fecha *)df->columnas[k].datos)[j] = ((Fecha *)df->columnas[k].datos)[j + 1];
                        ((Fecha *)df->columnas[k].datos)[j + 1] = tempDato;
                    }

                    unsigned char tempEsNulo = df->columnas[k].esNulo[j];
                    df->columnas[k].esNulo[j] = df->columnas[k].esNulo[j + 1];
                    df->columnas[k].esNulo[j + 1] = tempEsNulo;
                }
            }
        }
    }

    for (int i = 0; i < df->numFilas; i++) {
        df->indice[i] = i;
    }

    TextColor(GREEN);
    printf("Dataframe ordenado\n");
    TextColor(WHITE);
}



void meta(Dataframe *df) {
    if (df == NULL) {
        TextColor(RED);
        printf("No hay dataframe activo\n");
        TextColor(WHITE);
        return;
    }

    TextColor(GREEN);
    for (int i = 0; i < df->numColumnas; i++) {
        int numNulos = 0;
        for (int j = 0; j < df->numFilas; j++) {
            if (df->columnas[i].esNulo[j]) {
                    numNulos++;
            }
        }
        printf("Columna: %s, Tipo: ", df->columnas[i].nombre);
        switch (df->columnas[i].tipo) {
            case TEXTO:
                printf("TEXTO");
                break;
            case NUMERICO:
                printf("NUMERICO");
                break;
            case FECHA:
                printf("FECHA");
                break;
        }
        printf(", Valores nulos: %d\n", numNulos);
    }
    
    TextColor(WHITE);
}

void delnull(Dataframe *df, const char *nombre_columna) {
    int columna_index = -1;
    for (int i = 0; i < df->numColumnas; i++) {
        if (strcmp(df->columnas[i].nombre, nombre_columna) == 0) {
            columna_index = i;
            break;
        }
    }

    if (columna_index == -1) {
        TextColor(RED);
        printf("La columna %s no existe\n", nombre_columna);
        TextColor(WHITE);
        return;
    }

    int filasEliminadas = 0;
    for (int i = 0; i < df->numFilas; ) {
        if (df->columnas[columna_index].esNulo[df->indice[i]]) {
            eliminarFila(df, i);
            filasEliminadas++;
        } else {
            i++;
        }
    }

    TextColor(GREEN);
    if (filasEliminadas > 0) {
        printf("Se eliminaron %d filas con valores nulos en la columna %s\n", filasEliminadas, nombre_columna);
    } else {
        printf("La columna %s no tiene ningun valor nulo\n", nombre_columna);
    }
    TextColor(WHITE);
}

void guardado(Dataframe *df, const char *nombre) {

    if (df == NULL) {
        TextColor(RED);
        printf("No hay dataframe activo\n");
        TextColor(WHITE);
        return;
    }

    char *nombre_fichero_csv;
    if (nombre != NULL && strlen(nombre) > 0) {
        if (strstr(nombre, ".csv") != NULL) {
            nombre_fichero_csv = strdup(nombre); // Usar el nombre tal cual si ya contiene ".csv"
        } else {
            nombre_fichero_csv = malloc(strlen(nombre) + 5); // Asignar memoria para el nombre del archivo (+5 para ".csv" y '\0')
            if (nombre_fichero_csv == NULL) {
                TextColor(RED);
                printf("Error: No se pudo asignar memoria.\n\n");
                return;
            }
            sprintf(nombre_fichero_csv, "%s.csv", nombre); // Adjuntar ".csv" al final del nombre
        }
    } else {
        if (strstr(df->name, ".csv") != NULL) {
            nombre_fichero_csv = strdup(df->name); // Usar el nombre del dataframe tal cual si ya contiene ".csv"
        } else {
            nombre_fichero_csv = malloc(strlen(df->name) + 5); // Asignar memoria para el nombre del archivo (+5 para ".csv" y '\0')
            if (nombre_fichero_csv == NULL) {
                TextColor(RED);
                printf("Error: No se pudo asignar memoria.\n\n");
                return;
            }
            sprintf(nombre_fichero_csv, "%s.csv", df->name); // Adjuntar ".csv" al final del nombre del dataframe
        }
    }

    FILE *file = fopen(nombre_fichero_csv, "w"); // Crear/sobrescribir el archivo
    if (file == NULL) {
        TextColor(RED);
        perror("Error al crear el archivo");
        printf("\n");
        free(nombre_fichero_csv);
        return;
    }

    // Escribir encabezados
    for (int i = 0; i < df->numColumnas; i++) {
        fprintf(file, "%s", df->columnas[i].nombre);
        if (i < df->numColumnas - 1) {
            fprintf(file, ",");
        } else {
            fprintf(file, "\n");
        }
    }

    // Escribir datos usando el índice
    for (int i = 0; i < df->numFilas; i++) {
        int fila = df->indice[i];
        for (int j = 0; j < df->numColumnas; j++) {
            if (df->columnas[j].esNulo[fila]) {
                fprintf(file, "NULL");
            } else {
                switch (df->columnas[j].tipo) {
                    case TEXTO:
                        fprintf(file, "%s", ((char **)df->columnas[j].datos)[fila]);
                        break;
                    case NUMERICO:
                        fprintf(file, "%.2f", ((double *)df->columnas[j].datos)[fila]);
                        break;
                    case FECHA: {
                        struct tm *fecha = &((struct tm *)df->columnas[j].datos)[fila];
                        char buffer[64];
                        strftime(buffer, sizeof(buffer), "%Y-%m-%d", fecha);
                        fprintf(file, "%s", buffer);
                        break;
                    }
                    default:
                        break;
                }
            }
            if (j < df->numColumnas - 1) {
                fprintf(file, ",");
            } else {
                fprintf(file, "\n");
            }
        }
    }

    fclose(file);
    free(nombre_fichero_csv);

    TextColor(GREEN);
    printf("Dataframe guardado correctamente\n");
    TextColor(WHITE);
}





void quarter(Dataframe *df, const char *nombre_columna, const char *nombre_nueva_columna) {
    int columna_index = -1;
    for (int i = 0; i < df->numColumnas; i++) {
        if (strcmp(df->columnas[i].nombre, nombre_columna) == 0) {
            columna_index = i;
            break;
        }
    }

    if (columna_index == -1) {
        TextColor(RED);
        printf("La columna %s no existe\n", nombre_columna);
        TextColor(WHITE);
        return;
    }

    if (df->columnas[columna_index].tipo != FECHA) {
        TextColor(RED);
        printf("La columna %s no es de tipo FECHA\n", nombre_columna);
        TextColor(WHITE);
        return;
    }

    for (int i = 0; i < df->numColumnas; i++) {
        if (strcmp(df->columnas[i].nombre, nombre_nueva_columna) == 0) {
            TextColor(RED);
            printf("La columna %s ya existe\n", nombre_nueva_columna);
            TextColor(WHITE);
            return;
        }
    }

    df->numColumnas++;
    df->columnas = realloc(df->columnas, df->numColumnas * sizeof(Columna));
    if (df->columnas == NULL) {
        TextColor(RED);
        printf("Error al asignar memoria para la nueva columna\n");
        TextColor(WHITE);
        return;
    }

    for (int i = df->numColumnas - 1; i > columna_index + 1; i--) {
        df->columnas[i] = df->columnas[i - 1];
    }

    agregarColumna(df, nombre_nueva_columna, TEXTO, columna_index + 1);

    for (int i = 0; i < df->numFilas; i++) {
        int fila = df->indice[i];
        if (df->columnas[columna_index].esNulo[fila]) {
            ((char **)df->columnas[columna_index + 1].datos)[fila] = strdup("#N/A");
        } else {
            Fecha *fecha = &((Fecha *)df->columnas[columna_index].datos)[fila];
            int mes = fecha->tm_mon + 1;
            const char *trimestre;
            if (mes >= 1 && mes <= 3) {
                trimestre = "Q1";
            } else if (mes >= 4 && mes <= 6) {
                trimestre = "Q2";
            } else if (mes >= 7 && mes <= 9) {
                trimestre = "Q3";
            } else if (mes >= 10 && mes <= 12) {
                trimestre = "Q4";
            } else {
                trimestre = "#N/A";
            }
            ((char **)df->columnas[columna_index + 1].datos)[fila] = strdup(trimestre);
        }
        if (((char **)df->columnas[columna_index + 1].datos)[fila] == NULL) {
            TextColor(RED);
            printf("Error al asignar memoria para los datos de la nueva columna\n");
            TextColor(WHITE);
            return;
        }
    }

    TextColor(GREEN);
    printf("Columna %s creada correctamente\n", nombre_nueva_columna);
    TextColor(WHITE);
}

void prefix(Dataframe *df, const char *nombre_columna, int n, const char *nombre_nueva_columna) {
    if (n <= 0) {
        TextColor(RED);
        printf("El valor de n debe ser mayor que 0\n");
        TextColor(WHITE);
        return;
    }

    int columna_index = -1;
    for (int i = 0; i < df->numColumnas; i++) {
        if (strcmp(df->columnas[i].nombre, nombre_columna) == 0) {
            columna_index = i;
            break;
        }
    }

    if (columna_index == -1) {
        TextColor(RED);
        printf("La columna %s no existe\n", nombre_columna);
        TextColor(WHITE);
        return;
    }

    if (df->columnas[columna_index].tipo != TEXTO) {
        TextColor(RED);
        printf("La columna %s no es de tipo TEXTO\n", nombre_columna);
        TextColor(WHITE);
        return;
    }

    for (int i = 0; i < df->numColumnas; i++) {
        if (strcmp(df->columnas[i].nombre, nombre_nueva_columna) == 0) {
            TextColor(RED);
            printf("La columna %s ya existe\n", nombre_nueva_columna);
            TextColor(WHITE);
            return;
        }
    }

    df->numColumnas++;
    df->columnas = realloc(df->columnas, df->numColumnas * sizeof(Columna));
    if (df->columnas == NULL) {
        TextColor(RED);
        printf("Error al asignar memoria para la nueva columna\n");
        TextColor(WHITE);
        return;
    }

    for (int i = df->numColumnas - 1; i > columna_index + 1; i--) {
        df->columnas[i] = df->columnas[i - 1];
    }

    agregarColumna(df, nombre_nueva_columna, TEXTO, columna_index + 1);

    for (int i = 0; i < df->numFilas; i++) {
        int fila = df->indice[i];
        if (df->columnas[columna_index].esNulo[fila]) {
            ((char **)df->columnas[columna_index + 1].datos)[fila] = strdup("#N/A");
        } else {
            char *valor = ((char **)df->columnas[columna_index].datos)[fila];
            int len = strlen(valor);
            if (len < n) {
                ((char **)df->columnas[columna_index + 1].datos)[fila] = strdup(valor);
            } else {
                char *prefijo = (char *)malloc((n + 1) * sizeof(char));
                strncpy(prefijo, valor, n);
                prefijo[n] = '\0';
                ((char **)df->columnas[columna_index + 1].datos)[fila] = prefijo;
            }
        }
        if (((char **)df->columnas[columna_index + 1].datos)[fila] == NULL) {
            TextColor(RED);
            printf("Error al asignar memoria para los datos de la nueva columna\n");
            TextColor(WHITE);
            return;
        }
    }

    TextColor(GREEN);
    printf("Columna %s creada correctamente\n", nombre_nueva_columna);
    TextColor(WHITE);
}

void eliminarFila(Dataframe *df, int fila) {

    for (int i = 0; i < df->numColumnas; i++) {
        if (!df->columnas[i].esNulo[fila]) {
            switch (df->columnas[i].tipo) {
                case TEXTO:
                    free(((char **)df->columnas[i].datos)[fila]);
                    break;
                case NUMERICO:
                case FECHA:
                    // No se necesita liberar memoria adicional para estos tipos
                    break;
            }
        }
    }

    for (int i = fila; i < df->numFilas - 1; i++) {
        for (int j = 0; j < df->numColumnas; j++) {
            df->columnas[j].esNulo[i] = df->columnas[j].esNulo[i + 1];
            switch (df->columnas[j].tipo) {
                case TEXTO:
                    ((char **)df->columnas[j].datos)[i] = ((char **)df->columnas[j].datos)[i + 1];
                    break;
                case NUMERICO:
                    ((double *)df->columnas[j].datos)[i] = ((double *)df->columnas[j].datos)[i + 1];
                    break;
                case FECHA:
                    ((Fecha *)df->columnas[j].datos)[i] = ((Fecha *)df->columnas[j].datos)[i + 1];
                    break;
            }
        }
    }

    df->numFilas--;
    for (int i = 0; i < df->numColumnas; i++) {
        unsigned char *temp_esNulo = realloc(df->columnas[i].esNulo, df->numFilas * sizeof(unsigned char));
        if (temp_esNulo == NULL) {
            TextColor(RED);
            printf("Error al reasignar memoria para esNulo\n");
            TextColor(WHITE);
            for (int j = 0; j < i; j++) {
                free(df->columnas[j].esNulo);
                free(df->columnas[j].datos);
            }
            free(df->indice);
            free(df->columnas);
            free(df);
            return;
        }
        df->columnas[i].esNulo = temp_esNulo;

        void *temp_datos = NULL;
        switch (df->columnas[i].tipo) {
            case TEXTO:
                temp_datos = realloc(df->columnas[i].datos, df->numFilas * sizeof(char *));
                break;
            case NUMERICO:
                temp_datos = realloc(df->columnas[i].datos, df->numFilas * sizeof(double));
                break;
            case FECHA:
                temp_datos = realloc(df->columnas[i].datos, df->numFilas * sizeof(Fecha));
                break;
        }
        if (temp_datos == NULL) {
            TextColor(RED);
            printf("Error al reasignar memoria para datos\n");
            TextColor(WHITE);
            for (int j = 0; j < i; j++) {
                free(df->columnas[j].esNulo);
                free(df->columnas[j].datos);
            }
            free(df->indice);
            free(df->columnas);
            free(df);
            return;
        }
        df->columnas[i].datos = temp_datos;
    }

    int *temp_indice = realloc(df->indice, df->numFilas * sizeof(int));
    if (temp_indice == NULL) {
        TextColor(RED);
        printf("Error al reasignar memoria para indice\n");
        TextColor(WHITE);
        return;
    }
    df->indice = temp_indice;

    for (int i = 0; i < df->numFilas; i++) {
        df->indice[i] = i;
    }
}

void filter(Dataframe *df, const char *nombre_columna, const char *operador, const char *valor) {
    int columna_index = -1;
    for (int i = 0; i < df->numColumnas; i++) {
        if (strcmp(df->columnas[i].nombre, nombre_columna) == 0) {
            columna_index = i;
            break;
        }
    }

    if (columna_index == -1) {
        TextColor(RED);
        printf("La columna %s no existe\n", nombre_columna);
        TextColor(WHITE);
        return;
    }

    TipoDato tipo = df->columnas[columna_index].tipo;
    if (!validarDato(valor, tipo)) {
        TextColor(RED);
        printf("El valor %s no es del mismo tipo que la columna %s\n", valor, nombre_columna);
        TextColor(WHITE);
        return;
    }

    // Crear un array temporal para marcar las filas a eliminar
    int *filas_a_eliminar = malloc(df->numFilas * sizeof(int));
    if (filas_a_eliminar == NULL) {
        TextColor(RED);
        printf("Error al asignar memoria para filas_a_eliminar\n");
        TextColor(WHITE);
        return;
    }
    int num_filas_a_eliminar = 0;

    for (int i = 0; i < df->numFilas; i++) {
        int fila = df->indice[i];
        int cumple_condicion = 0;
        if (!df->columnas[columna_index].esNulo[fila]) {
            switch (tipo) {
                case TEXTO:
                    if (strcmp(operador, "eq") == 0) {
                        cumple_condicion = strcmp(((char **)df->columnas[columna_index].datos)[fila], valor) == 0;
                    } else if (strcmp(operador, "neq") == 0) {
                        cumple_condicion = strcmp(((char **)df->columnas[columna_index].datos)[fila], valor) != 0;
                    } else if (strcmp(operador, "gt") == 0) {
                        cumple_condicion = strcmp(((char **)df->columnas[columna_index].datos)[fila], valor) > 0;
                    } else if (strcmp(operador, "lt") == 0) {
                        cumple_condicion = strcmp(((char **)df->columnas[columna_index].datos)[fila], valor) < 0;
                    } else if (strcmp(operador, "get") == 0) {
                        cumple_condicion = strcmp(((char **)df->columnas[columna_index].datos)[fila], valor) >= 0;
                    } else if (strcmp(operador, "let") == 0) {
                        cumple_condicion = strcmp(((char **)df->columnas[columna_index].datos)[fila], valor) <= 0;
                    }
                    break;
                case NUMERICO: {
                    double valor_num = atof(valor);
                    double dato = ((double *)df->columnas[columna_index].datos)[fila];
                    if (strcmp(operador, "eq") == 0) {
                        cumple_condicion = dato == valor_num;
                    } else if (strcmp(operador, "neq") == 0) {
                        cumple_condicion = dato != valor_num;
                    } else if (strcmp(operador, "gt") == 0) {
                        cumple_condicion = dato > valor_num;
                    } else if (strcmp(operador, "lt") == 0) {
                        cumple_condicion = dato < valor_num;
                    } else if (strcmp(operador, "get") == 0) {
                        cumple_condicion = dato >= valor_num;
                    } else if (strcmp(operador, "let") == 0) {
                        cumple_condicion = dato <= valor_num;
                    }
                    break;
                }
                case FECHA: {
                    struct tm fecha;
                    fecha.tm_year = atoi(valor) - 1900;
                    fecha.tm_mon = atoi(valor + 5) - 1;
                    fecha.tm_mday = atoi(valor + 8);
                    fecha.tm_hour = fecha.tm_min = fecha.tm_sec = 0;
                    time_t tiempo_valor = mktime(&fecha);
                    time_t tiempo_dato = mktime(&((Fecha *)df->columnas[columna_index].datos)[fila]);
                    if (strcmp(operador, "eq") == 0) {
                        cumple_condicion = difftime(tiempo_dato, tiempo_valor) == 0;
                    } else if (strcmp(operador, "neq") == 0) {
                        cumple_condicion = difftime(tiempo_dato, tiempo_valor) != 0;
                    } else if (strcmp(operador, "gt") == 0) {
                        cumple_condicion = difftime(tiempo_dato, tiempo_valor) > 0;
                    } else if (strcmp(operador, "lt") == 0) {
                        cumple_condicion = difftime(tiempo_dato, tiempo_valor) < 0;
                    } else if (strcmp(operador, "get") == 0) {
                        cumple_condicion = difftime(tiempo_dato, tiempo_valor) >= 0;
                    } else if (strcmp(operador, "let") == 0) {
                        cumple_condicion = difftime(tiempo_dato, tiempo_valor) <= 0;
                    }
                    break;
                }
            }
        }

        if (!cumple_condicion || df->columnas[columna_index].esNulo[fila]) {
            filas_a_eliminar[num_filas_a_eliminar++] = fila;
        }
    }

    // Eliminar las filas marcadas
    for (int i = 0; i < num_filas_a_eliminar; i++) {
        eliminarFila(df, filas_a_eliminar[i]);
        for (int j = i; j < num_filas_a_eliminar - 1; j++) {
            filas_a_eliminar[j] = filas_a_eliminar[j + 1] - 1;
        }
        num_filas_a_eliminar--;
        i--;
    }

    free(filas_a_eliminar);

    TextColor(GREEN);
    printf("Filtrado aplicado correctamente\n");
    TextColor(WHITE);
}

//Función add:
//añadirá un dataframe al final del dataframe activo
//se debe pasar el nombre del dataframe a añadir
//también se podría pasar el separador del nuevo dataframe
//es una función analoga a la función load
//debe haber un dataframe activo
//el dataframe debe tener el mismo número de columnas que el dataframe activo
//el tipo de dato de cada columna debe ser el mismo que el del dataframe activo
//las cabeceras del nuevo dataframe no se tendrán en cuenta
//si no se cumple alguna de las condiciones anteriores se mostrará un mensaje de error
//si falla se deberá liberar la memoria reservada al nuevo dataframe, es decir, el dataframe inical se conservará
//en caso de que se cumplan las condiciones se añadirá el dataframe al final del dataframe activo
//si carga correctamente se actualizará el número de filas del dataframe activo, pero el nombre se conservará

void add(Dataframe *df, const char *nombre_archivo, char delimitador) {
    if (df == NULL) {
        TextColor(RED);
        printf("No hay dataframe activo\n");
        TextColor(WHITE);
        return;
    }

    Dataframe *nuevo_df = load(nombre_archivo, delimitador, 0); // No incrementar el contador
    if (nuevo_df == NULL) {
        TextColor(RED);
        printf("Error al cargar el nuevo dataframe\n");
        TextColor(WHITE);
        return;
    }

    if (nuevo_df->numColumnas != df->numColumnas) {
        TextColor(RED);
        printf("El nuevo dataframe no tiene el mismo número de columnas\n");
        TextColor(WHITE);
        EliminarDataframe(nuevo_df);
        return;
    }

    for (int i = 0; i < df->numColumnas; i++) {
        if (nuevo_df->columnas[i].tipo != df->columnas[i].tipo) {
            TextColor(RED);
            printf("El tipo de dato de la columna %d no coincide\n", i);
            TextColor(WHITE);
            EliminarDataframe(nuevo_df);
            return;
        }
    }

    int nuevas_filas = df->numFilas + nuevo_df->numFilas;
    for (int i = 0; i < df->numColumnas; i++) {
        void *temp_datos = NULL;
        switch (df->columnas[i].tipo) {
            case TEXTO:
                temp_datos = realloc(df->columnas[i].datos, nuevas_filas * sizeof(char *));
                break;
            case NUMERICO:
                temp_datos = realloc(df->columnas[i].datos, nuevas_filas * sizeof(double));
                break;
            case FECHA:
                temp_datos = realloc(df->columnas[i].datos, nuevas_filas * sizeof(Fecha));
                break;
        }
        unsigned char *temp_esNulo = realloc(df->columnas[i].esNulo, nuevas_filas * sizeof(unsigned char));
        if (temp_datos == NULL || temp_esNulo == NULL) {
            TextColor(RED);
            printf("Error al reasignar memoria\n");
            TextColor(WHITE);
            EliminarDataframe(nuevo_df);
            return;
        }
        df->columnas[i].datos = temp_datos;
        df->columnas[i].esNulo = temp_esNulo;
    }

    for (int i = 0; i < nuevo_df->numFilas; i++) {
        for (int j = 0; j < df->numColumnas; j++) {
            df->columnas[j].esNulo[df->numFilas + i] = nuevo_df->columnas[j].esNulo[i];
            switch (df->columnas[j].tipo) {
                case TEXTO:
                    ((char **)df->columnas[j].datos)[df->numFilas + i] = strdup(((char **)nuevo_df->columnas[j].datos)[i]);
                    break;
                case NUMERICO:
                    ((double *)df->columnas[j].datos)[df->numFilas + i] = ((double *)nuevo_df->columnas[j].datos)[i];
                    break;
                case FECHA:
                    ((Fecha *)df->columnas[j].datos)[df->numFilas + i] = ((Fecha *)nuevo_df->columnas[j].datos)[i];
                    break;
            }
        }
    }

    df->numFilas = nuevas_filas;
    int *temp_indice = realloc(df->indice, nuevas_filas * sizeof(int));
    if (temp_indice == NULL) {
        TextColor(RED);
        printf("Error al reasignar memoria para el índice\n");
        TextColor(WHITE);
        EliminarDataframe(nuevo_df);
        return;
    }
    df->indice = temp_indice;
    for (int i = 0; i < nuevas_filas; i++) {
        df->indice[i] = i;
    }

    EliminarDataframe(nuevo_df);
    TextColor(GREEN);
    printf("Dataframe añadido correctamente\n");
    TextColor(WHITE);
}



