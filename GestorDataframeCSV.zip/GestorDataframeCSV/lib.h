// Comprueba que la libreria no esta definida y como no lo está la define
#ifndef LIB_H
#define LIB_H

// Librerias añadidas
#include <windows.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
// Definiciones de colores
#define BLACK         0
#define BLUE          1
#define GREEN         2
#define CYAN          3
#define RED           4
#define MAGENTA       5
#define BROWN         6
#define LIGHTGRAY     7
#define DARKGRAY      8
#define LIGHTBLUE     9
#define LIGHTGREEN   10
#define LIGHTCYAN    11
#define LIGHTRED     12
#define LIGHTMAGENTA 13
#define YELLOW       14
#define WHITE        15

// Definiciones archivos y contadores
#define MAX_LINE_LENGTH 1024
#define MAX_FIELDS 100
#define FIELD_WIDTH 20 // Ancho de cada campo para la alineación



// Tipo enumerado para representar los diferentes tipos de datos en las columnas
typedef enum {
    TEXTO,
    NUMERICO,
    FECHA
} TipoDato;

// Estructura para representar una columna del dataframe
typedef struct {
    char nombre[30];       // Nombre de la columna
    TipoDato tipo;         // Tipo de datos de la columna (TEXTO, NUMERICO, FECHA)
    void *datos;           // Puntero genérico para almacenar los datos de la columna
    unsigned char *esNulo; // Array paralelo, indica valores nulos (1/0: nulo/noNulo)
    int numFilas;          // Número de filas en la columna
} Columna;

// Estructura para representar el dataframe como un conjunto de columnas
typedef struct {
    Columna *columnas;     // Array de columnas (con tipos de datos distintos)
    int numColumnas;       // Número de columnas en el dataframe
    int numFilas;          // Número de filas (igual para todas las columnas)
    int *indice;           // Array para ordenar las filas
    char name[56];         // Nombre del dataframe
} Dataframe;

typedef struct tm Fecha;   // Alias para tipos FECHA: 'Fecha' alias de 'struct tm' (#include <time.h>)




// Estructura para representar un nodo de la lista
typedef struct NodoLista {
    Dataframe *df;                // Puntero a un dataframe
    struct NodoLista *siguiente;   // Puntero al siguiente nodo de la lista
} Nodo;

// Estructura para representar la lista de Dataframe’s
typedef struct {
    int numDFs;       // Número de dataframes almacenados en la lista
    Nodo *primero;     // Puntero al primer Nodo de la lista
} Lista;


/*---------------------------------------------------------------------------------------*/




// FUNCIONES

void TextColor(int color);
char* trim(char *frase);
char *tokenizador(char *linea, char delimitador);
int ValidarFecha(const char *fecha);
int ValidarNumeroDecimal(const char *cadenad);
int ValidarNumeroEntero(const char *cadenae);
int ObtenerNumeroColumnas(const char *linea, char delimitador);
TipoDato ObtenerTipo(const char *dato);
Dataframe *load(const char *nombre_archivo, char delimitador, int incrementarContador);
void inicializarLista(Lista *lista);
void liberarDataframe(Dataframe *df);
void liberarLista(Lista *lista);
Dataframe* crearDataframe(int numColumnas, int numFilas, TipoDato *tipos, char *encabezados[]);
void EliminarDataframe(Dataframe *df);
void eliminarFila(Dataframe *df, int fila);
int insertarDato(Dataframe *df, int fila, int columna, const char *dato);
int InsertarDataframeAlFinal(Lista *lista, Dataframe *df);
void guardado(Dataframe *df, const char *nombre_fichero);
void agregarColumna(Dataframe *df, const char *nombre, TipoDato tipo,int i);
void guardarDataframeCSV(Dataframe *df, const char *nombreArchivo);
void listarDataframes(Lista *lista);
void cargarDataframeDesdeCSV(Lista *lista, const char *nombreArchivo);
void abrirCSV(Lista *lista , const char *nombreArchivo);
void ordenar(Dataframe *df, const char *nombreColumna, const char *orden); //No funciona bien, revisar
void meta(Dataframe *df);
void delnull(Dataframe *df, const char *nombre_columna);
void quarter(Dataframe *df, const char *nombre_columna, const char *nombre_nueva_columna);
void prefix(Dataframe *df, const char *nombre_columna, int n, const char *nombre_nueva_columna);
void filter(Dataframe *df, const char *nombre_columna, const char *operador, const char *valor);
void add(Dataframe *df, const char *nombre_archivo, char delimitador);




#endif // LIB_H