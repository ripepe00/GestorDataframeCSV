#include  "lib.h"
#include <stdio.h>
#include <string.h>
#include <ctype.h>


/*
void crearDataframeDesdeComando(Lista *lista, char *comando) {
    char comandoCopia[256];
    strcpy(comandoCopia, comando);
    int numColumnas = 0;
    char *token = strtok(comando, " ");
    token = strtok(NULL, " "); // Saltar el comando "create"
    printf("token: %s\n", token);
    // Contar el número de columnas
    while (token != NULL) {
        numColumnas++;
        token = strtok(NULL, " ");
        printf("token: %s\n", token);
    }

    if (numColumnas % 2 != 0) {
        printf("Número de argumentos inválido");
        return;
    }

    numColumnas /= 2;
    Dataframe *df = crearDataframe(numColumnas, 0); // Ejemplo: 5 filas
    token = strtok(comandoCopia, " ");
    token = strtok(NULL, " "); // Saltar el comando "create"
    sprintf(df->name,"df%d",lista->numDFs);
    
    for (int i = 0; i < numColumnas; i++) {
        char *nombre = token;
        token = strtok(NULL, " ");
        char *tipo = token;
        token = strtok(NULL, " ");

        printf("nombre: %s\n", nombre);
        printf("tipo: %s\n", tipo);

        TipoDato tipoDato;
        if (strcmp(tipo, "TEXTO") == 0) {
            tipoDato = TEXTO;
        } else if (strcmp(tipo, "NUMERICO") == 0) {
            tipoDato = NUMERICO;
        } else if (strcmp(tipo, "FECHA") == 0) {
            tipoDato = FECHA;
        } else {
            printf("Tipo de dato no válido");
            liberarDataframe(df);
            free(df);
            return;
        }

        agregarColumna(df, nombre, tipoDato,i);
    }

    Nodo *nuevoNodo = (Nodo *)malloc(sizeof(Nodo));
    nuevoNodo->siguiente = lista->primero;
    lista->primero = nuevoNodo;
    nuevoNodo->df = df;
    lista->numDFs++;
    printf("Dataframe creado");
}
*/




void imprimirDataframe(Dataframe *df) {
    if (df == NULL) {
        printf("Dataframe vacío\n");
        return;
    }

    // Imprimir encabezados
    for (int i = 0; i < df->numColumnas; i++) {
        printf("%s", df->columnas[i].nombre);
        if (i < df->numColumnas - 1) {
            printf(", ");
        }
    }
    printf("\n");

    // Imprimir datos
    for (int i = 0; i < df->numFilas; i++) {
        for (int j = 0; j < df->numColumnas; j++) {
            if (df->columnas[j].esNulo[i]) {
                printf("NULL");
            } else {
                switch (df->columnas[j].tipo) {
                    case TEXTO:
                        printf("%s", ((char **)df->columnas[j].datos)[i]);
                        break;
                    case NUMERICO:
                        printf("%f", ((double *)df->columnas[j].datos)[i]);
                        break;
                    case FECHA: {
                        Fecha *fecha = &((Fecha *)df->columnas[j].datos)[i];
                        printf("%04d-%02d-%02d", fecha->tm_year + 1900, fecha->tm_mon + 1, fecha->tm_mday);
                        break;
                    }
                }
            }
            if (j < df->numColumnas - 1) {
                printf(", ");
            }
        }
        printf("\n");
    }
}

void imprimirDataframeActivo(Dataframe *df) {
    if (df == NULL) {
        printf("No hay DataFrame activo.\n");
        return;
    }

    // Imprimir nombres de columnas
    for (int i = 0; i < df->numColumnas; i++) {
        printf("%s", df->columnas[i].nombre);
        if (i < df->numColumnas - 1) {
            printf(", ");
        }
    }
    printf("\n");

    // Imprimir datos
    for (int fila = 0; fila < df->numFilas; fila++) {
        for (int col = 0; col < df->numColumnas; col++) {
            if (df->columnas[col].esNulo[fila]) {
                printf("#N/A");
            } else {
                switch (df->columnas[col].tipo) {
                    case TEXTO:
                        printf("%s", ((char **)df->columnas[col].datos)[fila]);
                        break;
                    case NUMERICO:
                        printf("%f", ((double *)df->columnas[col].datos)[fila]);
                        break;
                    case FECHA: {
                        struct tm *fecha = &((struct tm *)df->columnas[col].datos)[fila];
                        printf("%04d-%02d-%02d", fecha->tm_year + 1900, fecha->tm_mon + 1, fecha->tm_mday);
                        break;
                    }
                }
            }
            if (col < df->numColumnas - 1) {
                printf(", ");
            }
        }
        printf("\n");
    }
}






//----------------------------------------------------------------------------------------------------------------------------------------------------------------






int main(){
    
    //Inicializar variables

    Dataframe *dfActivo = NULL;
    Dataframe *dfAuxiliar = NULL;

    Nodo *nodo = NULL;
    Lista lista;
    inicializarLista(&lista);

    TextColor(WHITE);

    char command[256];
    

    TextColor(15);
    while (1) {
        // Imprimir el prompt en color blanco
        TextColor(WHITE);
        if(dfActivo==NULL) 
            printf("\n[?]:> ");
        else
            printf("\n[%s: %d,%d]:> ", dfActivo->name, dfActivo->numFilas, dfActivo->numColumnas); // Blanco

        fgets(command, sizeof(command), stdin);
        command[strcspn(command, "\n")] = 0; // Eliminar el salto de línea


        // Comenzar con los entradas de usuario

        if (strlen(command) == 0) {
        TextColor(RED);
        printf("\nERROR: No has introducido ningun comando\n");
        TextColor(WHITE);
        continue;
        }

        else if (strcmp(command, "quit") == 0) {
            TextColor(2);
            printf("PROGRAM EXIT\n");
            liberarLista(&lista);
            TextColor(15);
            dfActivo = NULL;
            exit(0);
        }
        
        else if (strncmp(command, "create", 6) == 0) {
            //crearDataframeDesdeComando(&lista, command);
        }


        else if (strncmp(command, "list", 4) == 0) {
            printf("Numero de Dataframes: %d\n", lista.numDFs);
            listarDataframes(&lista);
        }

        /*else if(strncmp(command, "printA", 6) == 0) {
            if(dfActivo==NULL){
                TextColor(RED);
                printf("//ERROR No hay ningun dataframe activo\n");
                TextColor(WHITE);
                dfActivo=NULL;
            }
            else{
            imprimirDataframeActivo(dfActivo);
            }
        }*/

        /*else if (strncmp(command, "df", 2) == 0) {
            int numero = atoi(&command[2]); // Obtener el número del dataframe
            Nodo *actual = lista.primero;
            int encontrado = 0;
            while (actual != NULL) {
                if (numero == 0) {
                    dfActivo = actual->df;
                    encontrado = 1;
                    break;
                }
                actual = actual->siguiente;
                numero--;
            }

            if (encontrado) {
                
            } 
            
            else {
                TextColor(RED);
                printf("ERROR: Dataframe no encontrado\n");
                TextColor(WHITE);
            }
        }*/
        
    
        else if (strncmp(command, "load", 4) == 0) {
                char *token = strtok(command, " ");
                token = strtok(NULL, " "); // Obtener el nombre del archivo
            if (token == NULL) {
                TextColor(RED);
                printf("ERROR: Debes especificar el nombre del archivo a cargar\n");
                TextColor(WHITE);
                continue;
            }
    
            char *filename = token;
            char separator = ','; // Separador predeterminado
    
            token = strtok(NULL, " "); // Obtener el separador opcional
            if (token != NULL) {
                separator = token[0]; // Usar el primer carácter como separador
            }
    
            dfAuxiliar = load(filename, separator, 1); // Incrementar el contador
            if (dfAuxiliar == NULL) {
                TextColor(RED);
                printf("ERROR: No se pudo cargar el archivo\n");
                TextColor(WHITE);
            } 
            
            else {
                // Insertar el dataframe al final de la lista
                if (InsertarDataframeAlFinal(&lista, dfAuxiliar) == 0) {
                TextColor(RED);
                printf("ERROR: No se pudo insertar el dataframe en la lista\n");
                TextColor(WHITE);
                } 
            
                else {
                dfActivo = dfAuxiliar; // Hacer que el nuevo dataframe sea el activo
                }
            }
        }

        else if (strncmp(command, "delcolum", 8) == 0) {
            // Extraer el nombre de la columna del comando
            char *token = strtok(command, " "); // Dividir el comando
            token = strtok(NULL, " ");          // Obtener el nombre de la columna
            if (token == NULL) {
                TextColor(RED);
                printf("ERROR: Debes especificar el nombre de la columna a eliminar\n");
                TextColor(WHITE);
                continue;
            }

            char nombre[256];
            strncpy(nombre, token, sizeof(nombre) - 1);
            nombre[sizeof(nombre) - 1] = '\0'; // Asegurar terminación nula

            // Buscar la columna con el nombre especificado
            int columnaEncontrada = -1;
            for (int i = 0; i < dfActivo->numColumnas; i++) {
                if (strcmp(dfActivo->columnas[i].nombre, nombre) == 0) {
                    columnaEncontrada = i;
                    break;
                }
            }

            if (columnaEncontrada == -1) {
                TextColor(RED);
                printf("ERROR: Columna '%s' no encontrada\n", nombre);
                TextColor(WHITE);
                continue;
            }

            // Liberar los recursos asociados a la columna
            free(dfActivo->columnas[columnaEncontrada].esNulo);
            free(dfActivo->columnas[columnaEncontrada].datos);

            // Reorganizar las columnas restantes
            for (int i = columnaEncontrada; i < dfActivo->numColumnas - 1; i++) {
                dfActivo->columnas[i] = dfActivo->columnas[i + 1];
            }

            // Actualizar el número de columnas
            dfActivo->numColumnas--;

            // Opcional: Reducir el tamaño del arreglo de columnas
            dfActivo->columnas = realloc(dfActivo->columnas, dfActivo->numColumnas * sizeof(Columna));


        }

        /*else if (strncmp(command, "deletedataframe", 6) == 0) {
            if (dfActivo == NULL) {
                TextColor(RED);
                printf("ERROR: No hay un dataframe activo\n");
                TextColor(WHITE);
            } else {
                EliminarDataframe(dfActivo);
                dfActivo = NULL;
                TextColor(GREEN);
                printf("Dataframe eliminado correctamente\n");
                TextColor(WHITE);
            }
        }*/

        else if (strncmp(command, "name", 4) == 0) {
            char *token = strtok(command, " ");
            token = strtok(NULL, " "); // Saltar el comando "name"
            if (token != NULL) {
            // Lista de comandos disponibles
            const char *comandos[] = {"quit", "create", "list", "printA", "df", "load", "delcolum", "deletedataframe"/*, "select"*/, "sort", "view", "meta", "delnull", "save", "quarter", "prefix", "filter", "name"};
            int esComando = 0;
            for (int i = 0; i < sizeof(comandos) / sizeof(comandos[0]); i++) {
                if (strcmp(token, comandos[i]) == 0) {
                esComando = 1;
                break;
                }
            }
            if (esComando) {
                TextColor(RED);
                printf("ERROR: No se puede usar un comando como nombre de dataframe\n");
                TextColor(WHITE);
            } else {
                Nodo *actual = lista.primero;
                int nombreExistente = 0;
                while (actual != NULL) {
                if (strcmp(actual->df->name, token) == 0) {
                    nombreExistente = 1;
                    break;
                }
                actual = actual->siguiente;
                }
                if (nombreExistente) {
                TextColor(RED);
                printf("ERROR: Ya existe un dataframe con el nombre '%s'\n", token);
                TextColor(WHITE);
                } else {
                strcpy(dfActivo->name, token);
                TextColor(GREEN);
                printf("Nombre del dataframe actualizado\n");
                TextColor(WHITE);
                }
            }
            } else {
            TextColor(RED);
            printf("ERROR: Nombre no especificado\n");
            TextColor(WHITE);
            }
        }


        /*else if (strncmp(command, "select", 6) == 0) {
            char *token = strtok(command, " ");
            token = strtok(NULL, " "); // Obtener el nombre del dataframe
            if (token == NULL) {
            TextColor(RED);
            printf("ERROR: Debes especificar el nombre del dataframe a seleccionar\n");
            TextColor(WHITE);
            continue;
            }

            char nombre[256];
            strncpy(nombre, token, sizeof(nombre) - 1);
            nombre[sizeof(nombre) - 1] = '\0'; // Asegurar terminación nula

            Nodo *actual = lista.primero;
            int encontrado = 0;
            while (actual != NULL) {
            if (strcmp(actual->df->name, nombre) == 0) {
                dfActivo = actual->df;
                encontrado = 1;
                break;
            }
            actual = actual->siguiente;
            }

            if (encontrado) {
            TextColor(GREEN);
            printf("Dataframe '%s' seleccionado como activo\n", nombre);
            TextColor(WHITE);
            } else {
            TextColor(RED);
            printf("ERROR: Dataframe '%s' no encontrado\n", nombre);
            TextColor(WHITE);
            }
        }*/


        else if (strncmp(command, "sort", 4) == 0) {
            char *token = strtok(command, " ");
            token = strtok(NULL, " "); // Obtener el nombre de la columna
            if (token == NULL) {
            TextColor(RED);
            printf("ERROR: Debes especificar el nombre de la columna\n");
            TextColor(WHITE);
            continue;
            }
            char nombreColumna[256];
            strncpy(nombreColumna, token, sizeof(nombreColumna) - 1);
            nombreColumna[sizeof(nombreColumna) - 1] = '\0'; // Asegurar terminación nula

            token = strtok(NULL, " "); // Obtener el orden (asc o des)
            char orden[4] = "asc"; // Orden ascendente por defecto
            if (token != NULL) {
            strncpy(orden, token, sizeof(orden) - 1);
            orden[sizeof(orden) - 1] = '\0'; // Asegurar terminación nula
            }

            if (dfActivo == NULL) {
            TextColor(RED);
            printf("ERROR: No hay un dataframe activo\n");
            TextColor(WHITE);
            continue;
            }

            ordenar(dfActivo, nombreColumna, orden);
        }

        else if (strncmp(command, "view", 4) == 0) {
            if (strlen(command) > 4 && !isdigit(command[5])) {
            TextColor(RED);
            printf("ERROR: Comando no valido\n");
            TextColor(WHITE);
            continue;
            }

            char *token = strtok(command, " ");
            token = strtok(NULL, " "); // Obtener el número de filas a mostrar

            int numFilas = 10; // Valor por defecto
            if (token != NULL) {
            numFilas = atoi(token);
            if (numFilas == 0) {
                TextColor(RED);
                printf("ERROR: El número de filas debe ser distinto de 0\n");
                TextColor(WHITE);
                continue;
            }
            }

            if (dfActivo == NULL) {
            TextColor(RED);
            printf("ERROR: No hay un dataframe activo\n");
            TextColor(WHITE);
            continue;
            }

            // Imprimir nombres de columnas
            TextColor(GREEN);
            for (int i = 0; i < dfActivo->numColumnas; i++) {
            printf("%s", dfActivo->columnas[i].nombre);
            if (i < dfActivo->numColumnas - 1) {
                printf("\t");
            }
            }
            printf("\n");

            if (numFilas > 0) {
            // Imprimir datos desde el inicio
            for (int fila = 0; fila < numFilas && fila < dfActivo->numFilas; fila++) {
                for (int col = 0; col < dfActivo->numColumnas; col++) {
                if (dfActivo->columnas[col].esNulo[fila]) {
                    printf("#N/A");
                } else {
                    switch (dfActivo->columnas[col].tipo) {
                    case TEXTO:
                        printf("%s", ((char **)dfActivo->columnas[col].datos)[fila]);
                        break;
                    case NUMERICO:
                        printf("%f", ((double *)dfActivo->columnas[col].datos)[fila]);
                        break;
                    case FECHA: {
                        struct tm *fecha = &((struct tm *)dfActivo->columnas[col].datos)[fila];
                        printf("%04d-%02d-%02d", fecha->tm_year + 1900, fecha->tm_mon + 1, fecha->tm_mday);
                        break;
                    }
                    }
                }
                if (col < dfActivo->numColumnas - 1) {
                    printf("\t");
                }
                }
                printf("\n");
            }
            } else {
            // Imprimir datos desde el final
            numFilas = -numFilas;
            for (int fila = dfActivo->numFilas - numFilas; fila < dfActivo->numFilas; fila++) {
                if (fila < 0) continue;
                for (int col = 0; col < dfActivo->numColumnas; col++) {
                if (dfActivo->columnas[col].esNulo[fila]) {
                    printf("#N/A");
                } else {
                    switch (dfActivo->columnas[col].tipo) {
                    case TEXTO:
                        printf("%s", ((char **)dfActivo->columnas[col].datos)[fila]);
                        break;
                    case NUMERICO:
                        printf("%f", ((double *)dfActivo->columnas[col].datos)[fila]);
                        break;
                    case FECHA: {
                        struct tm *fecha = &((struct tm *)dfActivo->columnas[col].datos)[fila];
                        printf("%04d-%02d-%02d", fecha->tm_year + 1900, fecha->tm_mon + 1, fecha->tm_mday);
                        break;
                    }
                    }
                }
                if (col < dfActivo->numColumnas - 1) {
                    printf("\t");
                }
                }
                printf("\n");
            }
            }
            TextColor(WHITE);
        }


        else if (strncmp(command, "meta", 4) == 0) {
            // Verificar que el comando no tenga argumentos adicionales
            char *token = strtok(command, " ");
            token = strtok(NULL, " ");
            if (token != NULL) {
                TextColor(RED);
                printf("ERROR: El comando 'meta' no debe tener argumentos adicionales\n");
                TextColor(WHITE);
                continue;
            }

            // Verificar que haya un dataframe activo
            if (dfActivo == NULL) {
                TextColor(RED);
                printf("ERROR: No hay un dataframe activo\n");
                TextColor(WHITE);
                continue;
            }

            // Llamar a la función meta
            meta(dfActivo);

        }


        else if (strncmp(command, "delnull", 7) == 0) {
            // Extraer el nombre de la columna del comando
            char *token = strtok(command, " "); // Dividir el comando
            token = strtok(NULL, " ");          // Obtener el nombre de la columna
            if (token == NULL) {
                TextColor(RED);
                printf("ERROR: Debes especificar el nombre de la columna\n");
                TextColor(WHITE);
                continue;
            }

            if (dfActivo == NULL) {
                TextColor(RED);
                printf("ERROR: No hay un dataframe activo\n");
                TextColor(WHITE);
                continue;
            }

            char nombreColumna[256];
            strncpy(nombreColumna, token, sizeof(nombreColumna) - 1);
            nombreColumna[sizeof(nombreColumna) - 1] = '\0'; // Asegurar terminación nula

            // Llamar a la función dellnull
            delnull(dfActivo, nombreColumna);
        }

        else if (strncmp(command, "save", 4) == 0) {
            char *token = strtok(command, " ");
            token = strtok(NULL, " "); // Obtener el nombre del archivo

            if (dfActivo == NULL) {
            TextColor(RED);
            printf("ERROR: No hay un dataframe activo\n");
            TextColor(WHITE);
            continue;
            }
            
            guardado(dfActivo, token);
            
        }

        else if (strncmp(command, "quarter" , 7) == 0){

            char *token = strtok(command, " ");
            token = strtok(NULL, " "); // Obtener el nombre de la columna
            if (token == NULL) {
                TextColor(RED);
                printf("ERROR: Debes especificar el nombre de la columna\n");
                TextColor(WHITE);
                continue;
            }
            char nombre_columna[256];
            strncpy(nombre_columna, token, sizeof(nombre_columna) - 1);
            nombre_columna[sizeof(nombre_columna) - 1] = '\0'; // Asegurar terminación nula

            token = strtok(NULL, " "); // Obtener el nombre de la nueva columna
            if (token == NULL) {
                TextColor(RED);
                printf("ERROR: Debes especificar el nombre de la nueva columna\n");
                TextColor(WHITE);
                continue;
            }
            char nombre_nueva_columna[256];
            strncpy(nombre_nueva_columna, token, sizeof(nombre_nueva_columna) - 1);
            nombre_nueva_columna[sizeof(nombre_nueva_columna) - 1] = '\0'; // Asegurar terminación nula

            if (dfActivo == NULL) {
                TextColor(RED);
                printf("ERROR: No hay un dataframe activo\n");
                TextColor(WHITE);
                continue;
            }

            quarter(dfActivo, nombre_columna, nombre_nueva_columna);

        }

        else if(strncmp(command, "prefix" , 6) == 0){

            char *token = strtok(command, " ");
            token = strtok(NULL, " "); // Obtener el nombre de la columna
            if (token == NULL) {
                TextColor(RED);
                printf("ERROR: Debes especificar el nombre de la columna\n");
                TextColor(WHITE);
                continue;
            }
            char nombre_columna[256];
            strncpy(nombre_columna, token, sizeof(nombre_columna) - 1);
            nombre_columna[sizeof(nombre_columna) - 1] = '\0'; // Asegurar terminación nula

            token = strtok(NULL, " "); // Obtener el valor de n
            if (token == NULL) {
                TextColor(RED);
                printf("ERROR: Debes especificar el valor de n\n");
                TextColor(WHITE);
                continue;
            }
            int n = atoi(token);
            if (n <= 0) {
                TextColor(RED);
                printf("ERROR: El valor de n debe ser mayor que 0\n");
                TextColor(WHITE);
                continue;
            }

            token = strtok(NULL, " "); // Obtener el nombre de la nueva columna
            if (token == NULL) {
                TextColor(RED);
                printf("ERROR: Debes especificar el nombre de la nueva columna\n");
                TextColor(WHITE);
                continue;
            }
            char nombre_nueva_columna[256];
            strncpy(nombre_nueva_columna, token, sizeof(nombre_nueva_columna) - 1);
            nombre_nueva_columna[sizeof(nombre_nueva_columna) - 1] = '\0'; // Asegurar terminación nula

            if (dfActivo == NULL) {
                TextColor(RED);
                printf("ERROR: No hay un dataframe activo\n");
                TextColor(WHITE);
                continue;
            }

            prefix(dfActivo, nombre_columna, n, nombre_nueva_columna);

        }

        else if (strncmp(command, "filter", 6) == 0) {
            if (dfActivo == NULL) {
                TextColor(RED);
                printf("ERROR: No hay un dataframe activo\n");
                TextColor(WHITE);
                continue;
            }

            char *token = strtok(command, " ");
            token = strtok(NULL, " "); // Obtener el nombre de la columna
            if (token == NULL) {
                TextColor(RED);
                printf("ERROR: Debes especificar el nombre de la columna\n");
                TextColor(WHITE);
                continue;
            }
            char nombre_columna[256];
            strncpy(nombre_columna, token, sizeof(nombre_columna) - 1);
            nombre_columna[sizeof(nombre_columna) - 1] = '\0'; // Asegurar terminación nula

            token = strtok(NULL, " "); // Obtener el operador
            if (token == NULL) {
                TextColor(RED);
                printf("ERROR: Debes especificar el operador (eq, neq, gt, lt, let, get)\n");
                TextColor(WHITE);
                continue;
            }
            char operador[10];
            strncpy(operador, token, sizeof(operador) - 1);
            operador[sizeof(operador) - 1] = '\0'; // Asegurar terminación nula

            token = strtok(NULL, " "); // Obtener el valor
            if (token == NULL) {
                TextColor(RED);
                printf("ERROR: Debes especificar el valor\n");
                TextColor(WHITE);
                continue;
            }
            char valor[256];
            strncpy(valor, token, sizeof(valor) - 1);
            valor[sizeof(valor) - 1] = '\0'; // Asegurar terminación nula

            filter(dfActivo, nombre_columna, operador, valor);
        }



        else if (strncmp(command, "add", 3) == 0) {
            char *token = strtok(command, " ");
            token = strtok(NULL, " "); // Obtener el nombre del archivo
            if (token == NULL) {
                TextColor(RED);
                printf("ERROR: Debes especificar el nombre del archivo\n");
                TextColor(WHITE);
                continue;
            }
            char nombre_archivo[256];
            strncpy(nombre_archivo, token, sizeof(nombre_archivo) - 1);
            nombre_archivo[sizeof(nombre_archivo) - 1] = '\0'; // Asegurar terminación nula

            token = strtok(NULL, " "); // Obtener el delimitador opcional
            char delimitador = ','; // Delimitador por defecto
            if (token != NULL) {
                delimitador = token[0]; // Usar el primer carácter como delimitador
            }

            if (dfActivo == NULL) {
                TextColor(RED);
                printf("ERROR: No hay un dataframe activo\n");
                TextColor(WHITE);
                continue;
            }

            add(dfActivo, nombre_archivo, delimitador);
        }



        else if (lista.primero != NULL) {
            Nodo *actual = lista.primero;
            int encontrado = 0;
            while (actual != NULL) {
            if (strcmp(actual->df->name, command) == 0) {
                dfActivo = actual->df;
                encontrado = 1;
                break;
            }
            actual = actual->siguiente;
            }

            if (encontrado) {
            TextColor(GREEN);
            printf("Dataframe '%s' seleccionado como activo\n", command);
            TextColor(WHITE);
            } else {
            TextColor(RED);
            printf("ERROR: Comando no valido\n", command);
            TextColor(WHITE);
            }
        }



        else{
            TextColor(RED);
            printf("//ERROR Comando no valido.\n");
            TextColor(WHITE);
        }


    }


}




